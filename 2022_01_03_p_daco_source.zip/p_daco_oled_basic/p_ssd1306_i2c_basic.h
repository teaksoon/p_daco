#include <avr/io.h>

#define ADDR_I2C_R  0x79 // i2c Read Address, NOT USED
#define ADDR_I2C_W  0x78 // i2c Write Address(SSD1306OLED is a write only device)
#define ADDR_PAGE   0x22 // rows update - ( 0 to 7 ) each is 8-pixel vertical each=64 pixel (8x8)
#define ADDR_COL    0x21 // cols update - ( 0 to 127) each is pixel=128pixel
#define ADDR_DATA   0x40 // Address to start Data
#define ADDR_COMM   0x00 // Address to start Command
//
// --- start Function Declaration ---
void p_twi_init();
void p_twi_start(); 
void p_twi_stop();
void p_twi_write(char _cha);
char p_twi_read();

void p_twi_startComm(); 
void p_twi_memPos(uint8_t _row, uint8_t _col);
void p_twi_startData(); 

void p_ssd1306_begin(); 
void p_ssd1306_clear_frame();
void p_ssd1306_change_byte(uint8_t _row,uint8_t _col, uint8_t _byt);
// --- end Function Declaration ---

void p_twi_init() {
  TWSR = 1;TWBR = 0x0C;TWCR = (1<<TWEN);
}
void p_twi_start() {
  TWCR = (1<<TWINT)|(1<<TWSTA)|(1<<TWEN);
  while ((TWCR & (1<<TWINT))==0){}
}
void p_twi_stop() {
  TWCR = (1<<TWINT)|(1<<TWSTO)|(1<<TWEN);
}
void p_twi_write(char _cha) {
  TWDR = _cha;
  TWCR = (1<<TWINT)|(1<<TWEN);
  while((TWCR & (1<<TWINT))==0){}
}
char p_twi_read() {
  TWCR = (1 << TWINT) | (1 << TWEN);
  while ((TWCR & (1 << TWINT)) == 0) {}
  return TWDR;
}
void p_twi_startComm() { 
  p_twi_start();
  p_twi_write(ADDR_I2C_W); p_twi_write(ADDR_COMM);
}
void p_twi_memPos(uint8_t _row, uint8_t _col) {
  p_twi_startComm();
  p_twi_write(ADDR_PAGE); p_twi_write(_row);p_twi_write(7);
  p_twi_write(ADDR_COL);  p_twi_write(_col);p_twi_write(127);
  p_twi_stop(); 
}
void p_twi_startData() {
  p_twi_start();
  p_twi_write(ADDR_I2C_W); p_twi_write(ADDR_DATA); 
}

void p_ssd1306_begin() {
// Intital Setup Values for the SSD1306 I2C OLED 64x128 pixel Module
uint8_t initData[26]= { 
  0xAE,       // 0xAE Display OFF
  0xD5,0x80,  // 0xD5 Display Clock Div
  0xA8,0x3F,  // 0xA8 Set Multiplex: 0x1F for 128x32, 0x3F for 128x64
  0xD3,0x00,  // 0xD3 Set Display offset 0
  0x40,       // 0x40 Start Line 0
  0x8D,0x14,  // 0x8D Sevoid p_ssd1306_clear_frame()t Charge pump Enabled,internal VCC
  0x20,0x00,  // 0x20 Set Memory Mode: 0x00 for H, 0x01 for V
  0xA1,       // 0xA1 Rotate 180
  0xC8,       // 0xC8 Com Scan Dec
  0xDA,0x12,  // 0xDA Set COM Pins, 0x12 for h=64 or 0x02 for h=32
  0x81,0xCF,  // 0x81 Set Contrast
  0xD9,0xF1,  // 0xD9 Set pre-charge period
  0xDB,0x40,  // 0xDB Set vcom detect
  0xA4,       // 0xA4 all pixel 0N = A4, all pixel OFF=A5
  0xA6,       // 0xA6 Normal Display
  0x2E,       // 0x2E No Scroll
  0xAF        // 0xAF Display on
  }; 
  p_twi_init(); // set up AVR twi for I2C com  
  for (uint8_t i=0; i < 26; i++) {
    p_twi_startComm();    
    p_twi_write(initData[i]);
    p_twi_stop();    
  }
  p_ssd1306_clear_frame(); // Clear entire OLED
}

void p_ssd1306_clear_frame() {
  p_twi_memPos(0,0);
  p_twi_startData();
  for (uint8_t r=0; r < 8; r++) {
    for (uint8_t c=0; c < 128; c++) p_twi_write(0); // send to OLED
  } 
  p_twi_stop(); 
  p_twi_memPos(0,0);
}

void p_ssd1306_change_byte(uint8_t _row, uint8_t _col, uint8_t _byt) {
  p_twi_memPos(_row,_col);
  p_twi_startData();
  p_twi_write(_byt);
  p_twi_stop();
}
