#include <avr/io.h>
#include <avr/pgmspace.h> // use Program memory to store font array

#define ADDR_I2C_R  0x79 // i2c Read Address, NOT USED
#define ADDR_I2C_W  0x78 // i2c Write Address(SSD1306OLED is a write only device)
#define ADDR_PAGE   0x22 // rows update - ( 0 to 7 ) each is 8-pixel vertical each=64 pixel (8x8)
#define ADDR_COL    0x21 // cols update - ( 0 to 127) each is pixel=128pixel
#define ADDR_DATA   0x40 // Address to start Data
#define ADDR_COMM   0x00 // Address to start Command
//
// --- start Function Declaration ---
void p_twi_init();
void p_twi_start(); 
void p_twi_stop();
void p_twi_write(char _cha);
char p_twi_read();

void p_twi_startComm(); 
void p_twi_memPos(uint8_t _row, uint8_t _col);
void p_twi_startData(); 

void p_ssd1306_begin(); 
void p_ssd1306_show_frame();
void p_ssd1306_clear_frame();

// the following function will only be shown on OLED when p_ssd1306_show_frame() function is run
void p_ssd1306_bitmap(uint8_t _row,uint8_t _col,uint8_t *_a_byt,uint8_t _len,uint8_t _len_idx);
void p_ssd1306_empty_col(uint8_t _row, uint8_t _col, uint8_t _len);
void p_ssd1306_char(uint8_t _row,uint8_t _col,char _cha);
void p_ssd1306_string(uint8_t _row,uint8_t _col,char *_str);
void p_ssd1306_char_L(uint8_t _row,uint8_t _col,char _cha);
void p_ssd1306_string_L(uint8_t _row,uint8_t _col,char *_str);
void p_ssd1306_dot(uint8_t _row, uint8_t _col, uint8_t _state );
void p_ssd1306_line(uint8_t _row_1, uint8_t _col_1, uint8_t row_2, uint8_t _col_2, uint8_t _state);
void p_ssd1306_circle(uint8_t _row, uint8_t _col, uint8_t _radius, uint8_t _state); 
void p_ssd1306_radial(uint8_t _row, uint8_t _col, uint8_t _len, uint8_t _len_idx, uint8_t _step, uint8_t _step_idx, uint8_t _state);
// --- end Function Declaration ---

// --- start Global Vars ---
//
uint8_t       p_ssd1306_buffer[8][128]; // Graphics Memory Buffer
const float   p_pi = 3.14159267;        // Constant PI
const uint8_t p_font[] PROGMEM = {      // FONT ARRAY
 0b00000000,0b00000000,0b00000000,0b00000000,0b00000000,  /* space (ascii 32) */
 0b00000000,0b00000000,0b01011111,0b00000000,0b00000000,  /* ! */
 0b00000000,0b00000111,0b00000000,0b00000111,0b00000000,  /* " */
 0b00010100,0b01111111,0b00010100,0b01111111,0b00010100,  /* # */
 0b00100100,0b00101010,0b01111111,0b00101010,0b00010010,  /* $ */
 0b00100011,0b00010011,0b00001000,0b01100100,0b01100010,  /* % */
 0b00110110,0b01001001,0b01010101,0b00100010,0b01010000,  /* & */
 0b00000000,0b00000101,0b00000011,0b00000000,0b00000000,  /* ' */
 0b00000000,0b00011100,0b00100010,0b01000001,0b00000000,  /* ( */
 0b00000000,0b01000001,0b00100010,0b00011100,0b00000000,  /* ) */
 0b00010100,0b00001000,0b00111110,0b00001000,0b00010100,  /* * */
 0b00001000,0b00001000,0b00111110,0b00001000,0b00001000,  /* + */
 0b00000000,0b01010000,0b00110000,0b00000000,0b00000000,  /* , */
 0b00001000,0b00001000,0b00001000,0b00001000,0b00001000,  /* - */
 0b00000000,0b01100000,0b01100000,0b00000000,0b00000000,  /* .  */
 0b00100000,0b00010000,0b00001000,0b00000100,0b00000010,  /* / */
 0b00111110,0b01010001,0b01001001,0b01000101,0b00111110,  /* 0 (ascii 48) */
 0b00000000,0b01000010,0b01111111,0b01000000,0b00000000,  /* 1 */
 0b01000010,0b01100001,0b01010001,0b01001001,0b01000110,  /* 2 */
 0b00100001,0b01000001,0b01000101,0b01001011,0b00110001,  /* 3 */
 0b00011000,0b00010100,0b00010010,0b01111111,0b00010000,  /* 4 */
 0b00100111,0b01000101,0b01000101,0b01000101,0b00111001,  /* 5 */
 0b00111100,0b01001010,0b01001001,0b01001001,0b00110000,  /* 6 */
 0b00000001,0b01110001,0b00001001,0b00000101,0b00000011,  /* 7 */
 0b00110110,0b01001001,0b01001001,0b01001001,0b00110110,  /* 8 */
 0b00000110,0b01001001,0b01001001,0b00101001,0b00011110,  /* 9 (ascii 57) */
 0b00000000,0b00110110,0b00110110,0b00000000,0b00000000,  /* : */
 0b00000000,0b01010110,0b00110110,0b00000000,0b00000000,  /* ; */
 0b00001000,0b00010100,0b00100010,0b01000001,0b00000000,  /* < */
 0b00100100,0b00100100,0b00100100,0b00100100,0b00100100,  /* = */
 0b00000000,0b01000001,0b00100010,0b00010100,0b00001000,  /* > */
 0b00000010,0b00000001,0b01010001,0b00001001,0b00000110,  /* ?  */
 0b00110010,0b01001001,0b01111001,0b01000001,0b00111110,  /* @  */
 0b01111110,0b00001001,0b00001001,0b00001001,0b01111110,  /* A (ascii 65) */
 0b01111111,0b01001001,0b01001001,0b01001001,0b00110110,  /* B */
 0b00111110,0b01000001,0b01000001,0b01000001,0b00100010,  /* C */
 0b01111111,0b01000001,0b01000001,0b00100010,0b00011100,  /* D */
 0b01111111,0b01001001,0b01001001,0b01001001,0b01000001,  /* E */
 0b01111111,0b00001001,0b00001001,0b00001001,0b00000001,  /* F */
 0b00111110,0b01000001,0b01001001,0b01001001,0b01111010,  /* G */
 0b01111111,0b00001000,0b00001000,0b00001000,0b01111111,  /* H */
 0b00000000,0b01000001,0b01111111,0b01000001,0b00000000,  /* I */
 0b00100000,0b01000000,0b01000001,0b00111111,0b00000001,  /* J */
 0b01111111,0b00001000,0b00010100,0b00100010,0b01000001,  /* K */
 0b01111111,0b01000000,0b01000000,0b01000000,0b01000000,  /* L */
 0b01111111,0b00000010,0b00001100,0b00000010,0b01111111,  /* M */
 0b01111111,0b00000100,0b00001000,0b00010000,0b01111111,  /* N */
 0b00111110,0b01000001,0b01000001,0b01000001,0b00111110,  /* O */
 0b01111111,0b00001001,0b00001001,0b00001001,0b00000110,  /* P */
 0b00111110,0b01000001,0b01010001,0b00100001,0b01011110,  /* Q */
 0b01111111,0b00001001,0b00011001,0b00101001,0b01000110,  /* R */
 0b01000110,0b01001001,0b01001001,0b01001001,0b00110001,  /* S */
 0b00000001,0b00000001,0b01111111,0b00000001,0b00000001,  /* T */
 0b00111111,0b01000000,0b01000000,0b01000000,0b00111111,  /* U */ 
 0b00011111,0b00100000,0b01000000,0b00100000,0b00011111,  /* V */
 0b00111111,0b01000000,0b00111000,0b01000000,0b00111111,  /* W */
 0b01100011,0b00010100,0b00001000,0b00010100,0b01100011,  /* X */
 0b00000111,0b00001000,0b01110000,0b00001000,0b00000111,  /* Y */
 0b01100001,0b01010001,0b01001001,0b01000101,0b01000011,  /* Z */
 0b00000000,0b01111111,0b01000001,0b01000001,0b00000000,  /* [ */
 0b00000011,0b00000110,0b00011100,0b00110000,0b01100000,  /* backslash */
 0b00000000,0b01000001,0b01000001,0b01111111,0b00000000,  /* ] */
 0b00000100,0b00000010,0b00000001,0b00000010,0b00000100,  /* ^ */
 0b01000000,0b01000000,0b01000000,0b01000000,0b01000000,  /* _ */
 0b00000000,0b00000001,0b00000010,0b00000100,0b00000000,  /* ` */  
 0b00100000,0b01010100,0b01010100,0b01010100,0b01111000,  /* a (ascii 97) */
 0b01111111,0b01001000,0b01000100,0b01000100,0b00111000,  /* b */
 0b00111000,0b01000100,0b01000100,0b01000100,0b00000000,  /* c */
 0b00111000,0b01000100,0b01000100,0b01001000,0b01111111,  /* d */
 0b00111000,0b01010100,0b01010100,0b01010100,0b00011000,  /* e */
 0b00001000,0b01111110,0b00001001,0b00000001,0b00000010,  /* f */
 0b00001100,0b01010010,0b01010010,0b01010010,0b00111110,  /* g */
 0b01111111,0b00001000,0b00000100,0b00000100,0b01111000,  /* h */
 0b00000000,0b01000100,0b01111101,0b01000000,0b00000000,  /* i */
 0b00100000,0b01000000,0b01000100,0b00111101,0b00000000,  /* j */
 0b01111111,0b00010000,0b00101000,0b01000100,0b00000000,  /* k */
 0b00000000,0b00000001,0b01111111,0b01000000,0b00000000,  /* l */
 0b01111100,0b00000100,0b00011000,0b00000100,0b01111000,  /* m */
 0b01111100,0b00001000,0b00000100,0b00000100,0b01111000,  /* n */
 0b00111000,0b01000100,0b01000100,0b01000100,0b00111000,  /* o */
 0b01111100,0b00010100,0b00010100,0b00010100,0b00001000,  /* p */
 0b00001000,0b00010100,0b00010100,0b00011000,0b01111100,  /* q */
 0b01111100,0b00001000,0b00000100,0b00000100,0b00001000,  /* r */
 0b01001000,0b01010100,0b01010100,0b01010100,0b00100000,  /* s */
 0b00000100,0b00111111,0b01000100,0b01000000,0b00100000,  /* t */
 0b00111100,0b01000000,0b01000000,0b00100000,0b01111100,  /* u */
 0b00011100,0b00100000,0b01000000,0b00100000,0b00011100,  /* v */
 0b00111100,0b01000000,0b00110000,0b01000000,0b00111100,  /* w */
 0b01000100,0b00101000,0b00010000,0b00101000,0b01000100,  /* x */
 0b00001100,0b01010000,0b01010000,0b01010000,0b00111100,  /* y */
 0b01000100,0b01100100,0b01010100,0b01001100,0b01000100,  /* z (ascii 122) */
 0b00000000,0b00001000,0b00110110,0b01000001,0b00000000,  /* { */
 0b00000000,0b00000000,0b01111111,0b00000000,0b00000000,  /* | */
 0b00000000,0b01000001,0b00110110,0b00001000,0b00000000,  /* } */
 0b00010000,0b00001000,0b00001000,0b00010000,0b00001000   /* ~ (ascii 126) */
};
//
// --- end Global Vars ---

void p_twi_init() {
  TWSR = 1;TWBR = 0x0C;TWCR = (1<<TWEN);
}
void p_twi_start() {
  TWCR = (1<<TWINT)|(1<<TWSTA)|(1<<TWEN);
  while ((TWCR & (1<<TWINT))==0){}
}
void p_twi_stop() {
  TWCR = (1<<TWINT)|(1<<TWSTO)|(1<<TWEN);
}
void p_twi_write(char _cha) {
  TWDR = _cha;
  TWCR = (1<<TWINT)|(1<<TWEN);
  while((TWCR & (1<<TWINT))==0){}
}
char p_twi_read() {
  TWCR = (1 << TWINT) | (1 << TWEN);
  while ((TWCR & (1 << TWINT)) == 0) {}
  return TWDR;
}
void p_twi_startComm() { 
  p_twi_start();
  p_twi_write(ADDR_I2C_W); p_twi_write(ADDR_COMM);
}
void p_twi_memPos(uint8_t _row, uint8_t _col) {
  p_twi_startComm();
  p_twi_write(ADDR_PAGE); p_twi_write(_row);p_twi_write(7);
  p_twi_write(ADDR_COL);  p_twi_write(_col);p_twi_write(127);
  p_twi_stop(); 
}
void p_twi_startData() {
  p_twi_start();
  p_twi_write(ADDR_I2C_W); p_twi_write(ADDR_DATA); 
}

void p_ssd1306_begin() {
// Intital Setup Values for the SSD1306 I2C OLED 64x128 pixel Module
uint8_t initData[26]= { 
  0xAE,       // 0xAE Display OFF
  0xD5,0x80,  // 0xD5 Display Clock Div
  0xA8,0x3F,  // 0xA8 Set Multiplex: 0x1F for 128x32, 0x3F for 128x64
  0xD3,0x00,  // 0xD3 Set Display offset 0
  0x40,       // 0x40 Start Line 0
  0x8D,0x14,  // 0x8D Set Charge pump Enabled,internal VCC
  0x20,0x00,  // 0x20 Set Memory Mode: 0x00 for H, 0x01 for V
  0xA1,       // 0xA1 Rotate 180
  0xC8,       // 0xC8 Com Scan Dec
  0xDA,0x12,  // 0xDA Set COM Pins, 0x12 for h=64 or 0x02 for h=32
  0x81,0xCF,  // 0x81 Set Contrast
  0xD9,0xF1,  // 0xD9 Set pre-charge period
  0xDB,0x40,  // 0xDB Set vcom detect
  0xA4,       // 0xA4 all pixel 0N = A4, all pixel OFF=A5
  0xA6,       // 0xA6 Normal Display
  0x2E,       // 0x2E No Scroll
  0xAF        // 0xAF Display on
  }; 
  p_twi_init(); // set up AVR twi for I2C com  
  for (uint8_t i=0; i < 26; i++) {
    p_twi_startComm();    
    p_twi_write(initData[i]);
    p_twi_stop();    
  }
  p_ssd1306_clear_frame(); // Clear entire OLED
}

void p_ssd1306_show_frame() {
  p_twi_memPos(0,0);
  p_twi_startData();
  for (uint8_t r=0; r < 8; r++) {
    for (uint8_t c=0; c < 128; c++) p_twi_write(p_ssd1306_buffer[r][c]); // send to OLED
  } 
  p_twi_stop(); 
}

void p_ssd1306_clear_frame() {
  for (uint8_t r=0; r < 8; r++) {
    for (uint8_t c=0; c < 128; c++) p_ssd1306_buffer[r][c] = 0; // update buffer
  } 
  p_ssd1306_show_frame(); 
}

void p_ssd1306_empty_col(uint8_t _row, uint8_t _col, uint8_t _len) { 
  for (int i=0; i < _len; i++) { 
    p_ssd1306_buffer[_row][_col+i] = 0;  // update buffer
  } 
}

void p_ssd1306_bitmap(uint8_t _row, uint8_t _col, char *_a_byt, uint8_t _len, uint8_t _len_idx) {
  for (uint8_t i=0; i < _len; i++) {
    p_ssd1306_buffer[_row][_col+i] = _a_byt[i+_len_idx];  // update buffer
  }
}

void p_ssd1306_char(uint8_t _row, uint8_t _col, char _cha) {
uint8_t byt;  
  
  if (_cha < 32 || _cha > 126 ) return; // Ascii 32 to 126 only, Ignore the rest
  
  for (int i=0; i < 5; i++) { // EACH FONT is 5 byte in FONT ARRAY
    byt = pgm_read_byte( &p_font[((_cha-32)*5)+i] ); // read from PROGRAM MEMORY
    p_ssd1306_buffer[_row][_col+i] = byt;  // update buffer
  } 
}

void p_ssd1306_string(uint8_t _row, uint8_t _col, char *_str) {
uint8_t idx = 0;
  while (idx < 21) { // Maximum 21 chars, index 0 to 20
    p_ssd1306_char(_row,_col,_str[idx]); _col +=5;      
    idx++;
    if (_str[idx] == 0 || idx == 21) { 
      // Next Char is a NULL or Maximum Chars breached
      // Do not add Space to the Last Char in the String
      break; 
    } else {
      p_ssd1306_empty_col(_row,_col,1); _col+=1;  
    }
  }
}

void p_ssd1306_char_L(uint8_t _row, uint8_t _col, char _cha) {
char enlargeMask[]= {
  0b00000000,0b00000011,0b00001100,0b00001111,0b00110000,0b00110011,0b00111100,0b00111111,
  0b11000000,0b11000011,0b11001100,0b11001111,0b11110000,0b11110011,0b11111100,0b11111111
  };
char cTmp;    
 
  if (_cha < 32 || _cha > 126 ) return; // Ascii 32 to 126 only, Ignore the rest

  // Double Size, Top Part
  for (uint8_t i=0; i < 5; i++) {   
    cTmp = pgm_read_byte(&p_font[((_cha-32)*5)+i]);
    cTmp = cTmp & 0x0F;       // store LOW BYTE
    cTmp = enlargeMask[cTmp]; // mapped into Enlargement Mask
    p_ssd1306_buffer[_row][_col+(i*2)]   = cTmp;  // update buffer
    p_ssd1306_buffer[_row][_col+(i*2)+1] = cTmp;  // update buffer
  }
  // Double Size, Bottom Part        
  for (uint8_t i=0; i < 5; i++) {
    cTmp = pgm_read_byte(&p_font[((_cha-32)*5)+i]);
    cTmp = (cTmp&0xF0) >> 4 ; // store HIGH BYTE
    cTmp = enlargeMask[cTmp]; // mapped into Enlargement Mask
    p_ssd1306_buffer[_row+1][_col+(i*2)]   = cTmp;  // update buffer
    p_ssd1306_buffer[_row+1][_col+(i*2)+1] = cTmp;  // update buffer       
  } 
}

void p_ssd1306_string_L(uint8_t _row, uint8_t _col, char *_str) {
uint8_t idx = 0;
  while (idx < 10) { // Maximum 10 Large Chars, index 0 to 9
    p_ssd1306_char_L(_row,_col,_str[idx]); _col +=10; 
    idx++;
    if (_str[idx] == 0 || idx == 10) { 
      // Next Char is a NULL or Maximum Chars breached
      // Do not add Space to the Last Char in the String
      break; 
    } else {
      p_ssd1306_empty_col(_row,  _col,2); // Top Row
      p_ssd1306_empty_col(_row+1,_col,2); // Bottom Row
      _col+=2;       
    }
  }
}

void p_ssd1306_dot(uint8_t _row, uint8_t _col, uint8_t _state ) {
uint8_t mem_row;
 
  mem_row = _row/8;  // Convert from row pixel, OLED memory page 0- page7
  // UPDATE OLED MEMORY
  if ( _state == 1) {
    // turn ON
    p_ssd1306_buffer[mem_row][_col] = p_ssd1306_buffer[mem_row][_col] |  (1<<(_row % 8)); 
  } else {
    // turn OFF
    p_ssd1306_buffer[mem_row][_col] = p_ssd1306_buffer[mem_row][_col] & ~(1<<(_row % 8));
  }    
}

void p_ssd1306_line(uint8_t _row_1, uint8_t _col_1, uint8_t _row_2, uint8_t _col_2, uint8_t _state) { 
int drow,dcol,rs,cs,err,tmp;
  drow  = abs(_row_2-_row_1); 
  rs    = (_row_1 < _row_2) ? 1:-1;
  dcol  = abs(_col_2-_col_1); 
  cs    = (_col_1 < _col_2) ? 1:-1; 
  err   = ((drow > dcol) ? drow:-dcol)/2;
  for(;;) {
    p_ssd1306_dot(_row_1,_col_1,_state);
    if (_row_1==_row_2 && _col_1==_col_2) break;
    tmp = err;
    if (tmp > -drow) {err -= dcol; _row_1 += rs;}
    if (tmp <  dcol) {err += drow; _col_1 += cs;}
  }
} 

void p_ssd1306_circle(uint8_t _row, uint8_t _col, uint8_t _radius, uint8_t _state) {
int f     = 1-_radius;
int x     = 0;
int y     = _radius; 
int tmp_x = 0;
int tmp_y = -2*_radius;
  
  p_ssd1306_dot(_row,_col+_radius,_state);
  p_ssd1306_dot(_row,_col-_radius,_state);
  p_ssd1306_dot(_row+_radius,_col,_state);
  p_ssd1306_dot(_row-_radius,_col,_state);   
  
  while(x < y) {
    if(f >= 0) {
      y--; tmp_y += 2; f += tmp_y;
    }
    x++; tmp_x += 2; f += tmp_x+1;
    p_ssd1306_dot(_row+x,_col+y,_state); 
    p_ssd1306_dot(_row-x,_col+y,_state);
    p_ssd1306_dot(_row+x,_col-y,_state); 
    p_ssd1306_dot(_row-x,_col-y,_state);
    p_ssd1306_dot(_row+y,_col+x,_state); 
    p_ssd1306_dot(_row-y,_col+x,_state);
    p_ssd1306_dot(_row+y,_col-x,_state); 
    p_ssd1306_dot(_row-y,_col-x,_state);
  }
}

void p_ssd1306_radial(uint8_t _row, uint8_t _col, uint8_t _len, uint8_t _len_idx, uint8_t _step, uint8_t _step_idx, uint8_t _state) {
// _len  = line length (1 to n). _len_idx = starting pos away from _row,_col ( 0 to _len-1)
// _step = total steps in cirle ( eg 60 for 60seconds, 60 steps in circle). _step_idx = 0=vertical bar from _row,_col. Clockwise-Turn to _step-1
uint8_t row_1, row_2, col_1, col_2;

  row_1  = _row+( _len_idx * cos(p_pi-((2*p_pi)/_step) * _step_idx) );
  col_1  = _col+( _len_idx * sin(p_pi-((2*p_pi)/_step) * _step_idx) );
  row_2  = _row+(     _len * cos(p_pi-((2*p_pi)/_step) * _step_idx) );
  col_2  = _col+(     _len * sin(p_pi-((2*p_pi)/_step) * _step_idx) );
  
  p_ssd1306_line(row_1,col_1,row_2,col_2,_state);
}
